package externallink.externallink;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExternalLinkApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExternalLinkApplication.class, args);
	}
}
